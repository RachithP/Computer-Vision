function [u,sig,pii,Y,poly] = train_GMM(train_dir,K,Y)

%   Initializing few values
%   train_dir='train_images\*.jpg';
%   K = 5;

    max_iterations = 10; % Max number of iterations
    eps = 0.01; % Convergence criteria
    
    
%     % Training starts
%     train_images = dir(train_dir);
%     
%     Or = zeros(1);
%     Og = zeros(1);
%     Ob = zeros(1);
%     
%     for i = 1:length(train_images)
%         X = imread([train_images(i).folder '\' train_images(i).name]);
%         X = im2double(X);
%         X = imgaussfilt(X,4);
%         [I] = roipoly(X);
%         [x,y] = find(I);
%         for j = 1:length(x)
%             Or = [Or X(x(j),y(j),1)];
%             Og = [Og X(x(j),y(j),2)];
%             Ob = [Ob X(x(j),y(j),3)];
%         end
%     end
% 
%     twodsize = size(Or,2);
%     Or = Or(1,2:twodsize);
%     Og = Og(1,2:twodsize);
%     Ob = Ob(1,2:twodsize);
%     twodsize = size(Or,2);
%     Y = [Or;Og;Ob];

    twodsize = size(Y,2);

    % Calculating the co-variance matrix of 3-D [R,G,B] data
    sigOrange = ((Y-mean(Y,2))*(Y-mean(Y,2))')/twodsize;
    
    % Initializing parameters
    u = rand(3,K) % K 3x1 vectors
    sig = repmat(sigOrange,1,1,K); % nxnx3 3D array
%     sig = rand(3,3,K);
    pii = rand(1,K); % 1xK vector
    iter = 1;
    while (iter<=max_iterations)
        ui = u;
        % E-Step
        for i = 1:K               % For every gaussian model we are finding the optimized parameters.
            weight = zeros(1,twodsize);
            invsig = eye(3,3)\sig(:,:,i);
            for j = 1:twodsize    % For every pixel in the set of orange pixels obtained from the training set
                weight_den = 0;
                PCx = computePosterior(Y(:,j),u(:,i),sig(:,:,i),invsig);
                weight_num = pii(i)*PCx;
                for k = 1:K
                    invsigg = eye(3,3)\sig(:,:,k);
                    weight_den = weight_den + pii(k)*computePosterior(Y(:,j),u(:,k),sig(:,:,k),invsigg);
                end
                weight(j) = weight_num/weight_den;
            end
            
            % M-Step
            u(:,i) = (Y*(weight)')/sum(weight);
            sig(:,:,i) = ((((Y-u(:,i)).*weight)*(Y-u(:,i))'))/sum(weight);
            pii(i) = sum(weight)/twodsize;
        end
        iter = iter + 1;
        if (norm(sum(u-ui,2))<eps)
            break;
        end
    end
    
%   Calculating the relation between distance and area and getting the
%   coefficients of the polynomial
% Should do this the first time to get the relation and the polynomial
% coefficients, so that next time just plug it.
% Deriving the relation between area(total number of pixels) and distance
% of the orange ball using polyfit.
%     d = [106 114 121 137 144 152 160 168 176 192 200 208 216 223 231 248 256 264 280 68 76 91 99];
%     p = polyfit(a,d,2);
%     y = polyval(p,a);
%     plot(x,y1,'o')
    poly = [0.0015 -1.2887 336.1951];
    save('GMM_params.mat','sig','u','pii','Y','poly')

end