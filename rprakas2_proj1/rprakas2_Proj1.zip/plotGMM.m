function [] = plotGMM(u,sig,Y)
    figure;
    for i=1:size(u,2)
        [V,D] = eig(sig(:,:,i))
        W = mean(V,2);
%         points = 20;
%         [x,y,z] = sphere(points);
        [x, y, z] = ellipsoid(0,0,0,sqrt(D(1)),sqrt(D(4)),sqrt(D(9)),20);
        ap = [x(:) y(:) z(:)]';
        bp = (V*D*ap) + repmat(mean(u,2), 1, size(ap,2));
        xp = reshape(bp(1,:), size(x));
        yp = reshape(bp(2,:), size(y));
        zp = reshape(bp(3,:), size(z));
        S = surf(gca,xp,yp,zp);
        hold on
    end
    hold off
end